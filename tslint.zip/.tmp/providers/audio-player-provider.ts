import { Injectable } from '@angular/core';
import { AudioPlayerModel } from '../model/AudioModel';




@Injectable()
export class  WebAudioPlayer implements AudioPlayerModel
 {
 private audio: HTMLAudioElement;
 public src: string;
 public preload;
 public completed: number = 0;
 public isMusicPlaying: boolean = false;
 public isFinished: boolean = false;
 public progress: number = 0;
 public duration: number;
 public id: number;
 public isLoading: boolean;
 public isPaused:boolean;
 public hasLoaded: boolean;
 public showDuration:boolean;
 public pauseSrc:string;
 constructor()
 {
   this.createAudio();
 }
public createAudio() {
    this.audio = new Audio();
    this.audio.src = this.src;
    this.audio.preload = this.preload;

    this.audio.addEventListener("timeupdate", (e) => { this.onTimeUpdate(e); }, false);
    
    this.audio.addEventListener("error", (err) => {
      console.log(`Audio error => track ${this.src}`, err);
      this.isMusicPlaying = false;
    }, false);
    
    this.audio.addEventListener("canplay", () => {
      console.log(`Loaded track ${this.src}`);
      this.isLoading = false;
      this.hasLoaded = true;
      this.showDuration=true;

    }, false);
    
    this.audio.addEventListener("playing", () => {
      console.log(`Playing track ${this.src}`);
      this.isFinished = false;
      this.isMusicPlaying = true;
      this.isPaused=false;
       this.pauseSrc="";
    }, false);

    this.audio.addEventListener("pause", () => {
      this.isMusicPlaying =false;
      this.isPaused=true;
      this.isFinished = false;
      this.pauseSrc=this.audio.src;

      this.progress=this.audio.currentTime;
      console.log('Paused playback');
    }, false);
    
    this.audio.addEventListener("ended", () => {
      this.isMusicPlaying = false;
      this.isFinished = true;
      console.log('Finished playback');
    }, false);


    
    this.audio.addEventListener("durationchange", (e:any) => {    
      this.duration = e.target.duration;
    }, false); 
  

}
private onTimeUpdate(e: Event) {
    if (this.isMusicPlaying && this.audio.currentTime > 0) {
      this.progress = this.audio.currentTime;
      this.completed = this.audio.duration > 0 ? Math.trunc (this.audio.currentTime / this.audio.duration * 100)/100 : 0;
    }  
  }

 play() {
    
   

    if (!this.audio) {
      this.createAudio();   
    }      
   
    if (!this.hasLoaded) {
      console.log(`Loading track ${this.src}`);
      this.isLoading = true;
    }


    this.audio.play();
  /*  this.isMusicPlaying=true;*/
  } 

  pause()
  {
    if (!this.isMusicPlaying) return;
    this.audio.pause();
  }

  stop() {
    if (!this.audio) return;
    this.pause();
    this.audio.removeEventListener("timeupdate", (e) => {this.onTimeUpdate(e);});
    this.isFinished = true;
    this.progress=0;
    this.destroy();
  }
  
  

  seekTo(time: number) {
    this.audio.currentTime = time;  
  }
  
 
  destroy() {
    this.audio = undefined;  
    console.log(`Released track ${this.src}`);
  }
  

}

