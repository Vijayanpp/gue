import { AudioPlayerModel } from '../model/AudioModel';
export declare class WebAudioPlayer implements AudioPlayerModel {
    private audio;
    src: string;
    preload: any;
    completed: number;
    isMusicPlaying: boolean;
    isFinished: boolean;
    progress: number;
    duration: number;
    id: number;
    isLoading: boolean;
    isPaused: boolean;
    hasLoaded: boolean;
    showDuration: boolean;
    pauseSrc: string;
    constructor();
    createAudio(): void;
    private onTimeUpdate(e);
    play(): void;
    pause(): void;
    stop(): void;
    seekTo(time: number): void;
    destroy(): void;
}
