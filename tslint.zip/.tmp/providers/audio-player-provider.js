import { Injectable } from '@angular/core';
export var WebAudioPlayer = (function () {
    function WebAudioPlayer() {
        this.completed = 0;
        this.isMusicPlaying = false;
        this.isFinished = false;
        this.progress = 0;
        this.createAudio();
    }
    WebAudioPlayer.prototype.createAudio = function () {
        var _this = this;
        this.audio = new Audio();
        this.audio.src = this.src;
        this.audio.preload = this.preload;
        this.audio.addEventListener("timeupdate", function (e) { _this.onTimeUpdate(e); }, false);
        this.audio.addEventListener("error", function (err) {
            console.log("Audio error => track " + _this.src, err);
            _this.isMusicPlaying = false;
        }, false);
        this.audio.addEventListener("canplay", function () {
            console.log("Loaded track " + _this.src);
            _this.isLoading = false;
            _this.hasLoaded = true;
            _this.showDuration = true;
        }, false);
        this.audio.addEventListener("playing", function () {
            console.log("Playing track " + _this.src);
            _this.isFinished = false;
            _this.isMusicPlaying = true;
            _this.isPaused = false;
            _this.pauseSrc = "";
        }, false);
        this.audio.addEventListener("pause", function () {
            _this.isMusicPlaying = false;
            _this.isPaused = true;
            _this.isFinished = false;
            _this.pauseSrc = _this.audio.src;
            _this.progress = _this.audio.currentTime;
            console.log('Paused playback');
        }, false);
        this.audio.addEventListener("ended", function () {
            _this.isMusicPlaying = false;
            _this.isFinished = true;
            console.log('Finished playback');
        }, false);
        this.audio.addEventListener("durationchange", function (e) {
            _this.duration = e.target.duration;
        }, false);
    };
    WebAudioPlayer.prototype.onTimeUpdate = function (e) {
        if (this.isMusicPlaying && this.audio.currentTime > 0) {
            this.progress = this.audio.currentTime;
            this.completed = this.audio.duration > 0 ? Math.trunc(this.audio.currentTime / this.audio.duration * 100) / 100 : 0;
        }
    };
    WebAudioPlayer.prototype.play = function () {
        if (!this.audio) {
            this.createAudio();
        }
        if (!this.hasLoaded) {
            console.log("Loading track " + this.src);
            this.isLoading = true;
        }
        this.audio.play();
        /*  this.isMusicPlaying=true;*/
    };
    WebAudioPlayer.prototype.pause = function () {
        if (!this.isMusicPlaying)
            return;
        this.audio.pause();
    };
    WebAudioPlayer.prototype.stop = function () {
        var _this = this;
        if (!this.audio)
            return;
        this.pause();
        this.audio.removeEventListener("timeupdate", function (e) { _this.onTimeUpdate(e); });
        this.isFinished = true;
        this.progress = 0;
        this.destroy();
    };
    WebAudioPlayer.prototype.seekTo = function (time) {
        this.audio.currentTime = time;
    };
    WebAudioPlayer.prototype.destroy = function () {
        this.audio = undefined;
        console.log("Released track " + this.src);
    };
    WebAudioPlayer.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    WebAudioPlayer.ctorParameters = [];
    return WebAudioPlayer;
}());
