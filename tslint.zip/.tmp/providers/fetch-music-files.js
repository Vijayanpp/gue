import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
;
import 'rxjs/add/operator/map';
/*
  Generated class for the FetchMusicFiles provider.
*/
export var FetchMusicFiles = (function () {
    function FetchMusicFiles(http) {
        this.http = http;
        this.musicApiUrl = 'music.json';
    }
    FetchMusicFiles.prototype.load = function () {
        return this.http.get("" + this.musicApiUrl)
            .map(function (res) { return res.json(); });
    };
    FetchMusicFiles.decorators = [
        { type: Injectable },
    ];
    /** @nocollapse */
    FetchMusicFiles.ctorParameters = [
        { type: Http, },
    ];
    return FetchMusicFiles;
}());
