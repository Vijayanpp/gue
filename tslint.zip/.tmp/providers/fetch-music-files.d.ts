import { Http } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { Music } from '../model/musicmodel';
export declare class FetchMusicFiles {
    http: Http;
    musicApiUrl: string;
    constructor(http: Http);
    load(): Observable<Music[]>;
}
