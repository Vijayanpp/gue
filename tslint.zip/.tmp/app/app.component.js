import { Component, ViewChild } from '@angular/core';
import { Platform, MenuController, Nav } from 'ionic-angular';
import { StatusBar } from 'ionic-native';
import { Homepage } from '../pages/homepage/homepage';
import { Musicfiles } from '../pages/musicfiles/musicfiles';
export var MyApp = (function () {
    function MyApp(platform, menu) {
        this.platform = platform;
        this.menu = menu;
        // make Musicfiles the root (or first) page
        this.rootPage = Homepage;
        this.initializeApp();
        // set our app's pages
        this.pages = [
            { title: 'Home Page', component: Musicfiles },
            { title: 'Music Page', component: Musicfiles }
        ];
        this.muusicfiles = Musicfiles;
    }
    MyApp.prototype.initializeApp = function () {
        this.platform.ready().then(function () {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            StatusBar.styleDefault();
        });
    };
    MyApp.prototype.openPage = function (page) {
        this.nav.push(page);
    };
    MyApp.decorators = [
        { type: Component, args: [{
                    templateUrl: 'app.html'
                },] },
    ];
    /** @nocollapse */
    MyApp.ctorParameters = [
        { type: Platform, },
        { type: MenuController, },
    ];
    MyApp.propDecorators = {
        'nav': [{ type: ViewChild, args: [Nav,] },],
    };
    return MyApp;
}());
