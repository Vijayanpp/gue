import { NgModule } from '@angular/core';
import { IonicApp, IonicModule } from 'ionic-angular';
import { MyApp } from './app.component';
import { Musicfiles } from '../pages/musicfiles/musicfiles';
import { Homepage } from '../pages/homepage/homepage';
import { Audioplayer } from '../pages/audioplayer/audioplayer';
import { Audiotrackplay } from '../pages/audiotrackplay/audiotrackplay';
import { FetchMusicFiles } from '../providers/fetch-music-files';
import { WebAudioPlayer } from '../providers/audio-player-provider';
import { AudioTimePipe } from '../pipes/audio-time-pipe';
export var AppModule = (function () {
    function AppModule() {
    }
    AppModule.decorators = [
        { type: NgModule, args: [{
                    declarations: [
                        MyApp,
                        Homepage,
                        Musicfiles,
                        Audioplayer,
                        Audiotrackplay,
                        AudioTimePipe
                    ],
                    imports: [
                        IonicModule.forRoot(MyApp)
                    ],
                    bootstrap: [IonicApp],
                    entryComponents: [
                        MyApp,
                        Homepage,
                        Musicfiles
                    ],
                    providers: [FetchMusicFiles, WebAudioPlayer]
                },] },
    ];
    /** @nocollapse */
    AppModule.ctorParameters = [];
    return AppModule;
}());
