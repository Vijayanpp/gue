
export interface Music
{
	id:number;
	src:string;
	title:string;
	artist:string;
	duration:string;
	isPlaying:boolean;

}