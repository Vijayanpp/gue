import { WebAudioPlayer } from '../../providers/audio-player-provider';
import { ElementRef, Renderer } from '@angular/core';
export declare class Audioplayer {
    el: ElementRef;
    private renderer;
    webAudioPlayer: WebAudioPlayer;
    completed: number;
    range: number;
    showDuration: boolean;
    showProgress: boolean;
    constructor(el: ElementRef, renderer: Renderer, webAudioPlayer: WebAudioPlayer);
    ionViewDidLoad(): void;
    progress: boolean;
    duration: boolean;
    ngOnInit(): void;
    ngDoCheck(): void;
    seekTo(): void;
}
