import { Component, Input } from '@angular/core';
import { WebAudioPlayer } from '../../providers/audio-player-provider';
import { ElementRef, Renderer } from '@angular/core';
export var Audioplayer = (function () {
    function Audioplayer(el, renderer, webAudioPlayer) {
        this.el = el;
        this.renderer = renderer;
        this.webAudioPlayer = webAudioPlayer;
    }
    Audioplayer.prototype.ionViewDidLoad = function () {
    };
    Object.defineProperty(Audioplayer.prototype, "progress", {
        set: function (v) {
            this.showProgress = true;
        },
        enumerable: true,
        configurable: true
    });
    Object.defineProperty(Audioplayer.prototype, "duration", {
        set: function (v) {
            this.showDuration = true;
        },
        enumerable: true,
        configurable: true
    });
    Audioplayer.prototype.ngOnInit = function () {
        this.renderer.setElementStyle(this.el.nativeElement, 'width', '100%');
    };
    Audioplayer.prototype.ngDoCheck = function () {
        this.showProgress = true;
        this.showDuration = this.webAudioPlayer.showDuration;
        if (this.webAudioPlayer.completed >= 0 && !Object.is(this.webAudioPlayer.completed, this.completed)) {
            this.completed = this.webAudioPlayer.completed;
            console.log(this.webAudioPlayer.showDuration);
            console.log(this.completed);
            this.range = Math.round(this.completed * 100 * 100) / 100;
        }
    };
    Audioplayer.prototype.seekTo = function () {
        var seekTo = Math.round(this.webAudioPlayer.duration * this.range) / 100;
        if (!Number.isNaN(seekTo))
            this.webAudioPlayer.seekTo(seekTo);
    };
    Audioplayer.decorators = [
        { type: Component, args: [{
                    selector: 'audioplayer',
                    templateUrl: 'audioplayer.html',
                },] },
    ];
    /** @nocollapse */
    Audioplayer.ctorParameters = [
        { type: ElementRef, },
        { type: Renderer, },
        { type: WebAudioPlayer, },
    ];
    Audioplayer.propDecorators = {
        'progress': [{ type: Input },],
        'duration': [{ type: Input },],
    };
    return Audioplayer;
}());
