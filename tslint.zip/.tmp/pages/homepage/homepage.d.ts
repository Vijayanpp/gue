import { NavController } from 'ionic-angular';
export declare class Homepage {
    navCtrl: NavController;
    constructor(navCtrl: NavController);
    ionViewDidLoad(): void;
    openPage(): void;
}
