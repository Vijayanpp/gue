import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Musicfiles } from '../musicfiles/musicfiles'


@Component({
  selector: 'page-homepage',
  templateUrl: 'homepage.html'
})
export class Homepage {

  constructor(public navCtrl: NavController) {}
  
  ionViewDidLoad() {
   }
  
  /*we push a page into the navigation stack. Going back or pressing the back button is like popping the last element in the stack (Last In First Out).*/

  openPage() {
    
    this.navCtrl.push(Musicfiles);
  }

}
