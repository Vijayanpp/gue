import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Musicfiles } from '../musicfiles/musicfiles';
export var Homepage = (function () {
    function Homepage(navCtrl) {
        this.navCtrl = navCtrl;
    }
    Homepage.prototype.ionViewDidLoad = function () {
    };
    /*we push a page into the navigation stack. Going back or pressing the back button is like popping the last element in the stack (Last In First Out).*/
    Homepage.prototype.openPage = function () {
        this.navCtrl.push(Musicfiles);
    };
    Homepage.decorators = [
        { type: Component, args: [{
                    selector: 'page-homepage',
                    templateUrl: 'homepage.html'
                },] },
    ];
    /** @nocollapse */
    Homepage.ctorParameters = [
        { type: NavController, },
    ];
    return Homepage;
}());
