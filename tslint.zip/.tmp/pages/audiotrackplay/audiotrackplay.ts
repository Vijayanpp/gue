import {
    Component,
    Input,
    Output,
    EventEmitter,
    ViewChild
} from '@angular/core';
import {
    NavController
} from 'ionic-angular';
import {
    Music
} from '../../model/musicmodel';
import {
    WebAudioPlayer
} from '../../providers/audio-player-provider';

@Component({
    selector: 'audio-track-play',
    templateUrl: 'audiotrackplay.html'
})
export class Audiotrackplay {


    public selectedMusicFile: Music;
    public isPlaying;
    public isPaused;

    @Output() MusicStatusChange: EventEmitter < any >= new EventEmitter();


    @Input() music: Music;

    constructor(public webAudioPlayer: WebAudioPlayer) {}

    ionViewDidLoad() {

    }




    playMusic(src) {
        let pauseSrc1

        if (this.webAudioPlayer.pauseSrc !== undefined) {
            let pauseSrc = this.webAudioPlayer.pauseSrc.split("/");
            pauseSrc1 = pauseSrc[pauseSrc.length - 1];
        }
        if (this.webAudioPlayer.isMusicPlaying == true) {
            console.log("currently music is playing so need to stop");
            this.MusicStatusChange.emit(src);
            this.music.isPlaying = true;

        } else if (this.isPaused == true && this.webAudioPlayer.isMusicPlaying == false && pauseSrc1 == src) {
            this.webAudioPlayer.play();
            this.music.isPlaying = true;
        } else {

            this.webAudioPlayer.src = src;
            this.webAudioPlayer.createAudio();
            this.webAudioPlayer.play();
            this.music.isPlaying = true;
        }
    }


    pauseMusic() {

        this.webAudioPlayer.pause();
        this.music.isPlaying = false;
        this.isPaused = true;

    }

    stopMusic() {
        this.webAudioPlayer.stop();
        this.music.isPlaying = false;
        this.isPaused = false;
    }




    onSelect(music: Music): void {

        this.selectedMusicFile = music;
        let src = this.selectedMusicFile.src;
        this.playMusic(src);

    }


}