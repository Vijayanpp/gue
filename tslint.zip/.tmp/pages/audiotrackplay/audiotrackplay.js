import { Component, Input, Output, EventEmitter } from '@angular/core';
import { WebAudioPlayer } from '../../providers/audio-player-provider';
export var Audiotrackplay = (function () {
    function Audiotrackplay(webAudioPlayer) {
        this.webAudioPlayer = webAudioPlayer;
        this.MusicStatusChange = new EventEmitter();
    }
    Audiotrackplay.prototype.ionViewDidLoad = function () {
    };
    Audiotrackplay.prototype.playMusic = function (src) {
        var pauseSrc1;
        if (this.webAudioPlayer.pauseSrc !== undefined) {
            var pauseSrc = this.webAudioPlayer.pauseSrc.split("/");
            pauseSrc1 = pauseSrc[pauseSrc.length - 1];
        }
        if (this.webAudioPlayer.isMusicPlaying == true) {
            console.log("currently music is playing so need to stop");
            this.MusicStatusChange.emit(src);
            this.music.isPlaying = true;
        }
        else if (this.isPaused == true && this.webAudioPlayer.isMusicPlaying == false && pauseSrc1 == src) {
            this.webAudioPlayer.play();
            this.music.isPlaying = true;
        }
        else {
            this.webAudioPlayer.src = src;
            this.webAudioPlayer.createAudio();
            this.webAudioPlayer.play();
            this.music.isPlaying = true;
        }
    };
    Audiotrackplay.prototype.pauseMusic = function () {
        this.webAudioPlayer.pause();
        this.music.isPlaying = false;
        this.isPaused = true;
    };
    Audiotrackplay.prototype.stopMusic = function () {
        this.webAudioPlayer.stop();
        this.music.isPlaying = false;
        this.isPaused = false;
    };
    Audiotrackplay.prototype.onSelect = function (music) {
        this.selectedMusicFile = music;
        var src = this.selectedMusicFile.src;
        this.playMusic(src);
    };
    Audiotrackplay.decorators = [
        { type: Component, args: [{
                    selector: 'audio-track-play',
                    templateUrl: 'audiotrackplay.html'
                },] },
    ];
    /** @nocollapse */
    Audiotrackplay.ctorParameters = [
        { type: WebAudioPlayer, },
    ];
    Audiotrackplay.propDecorators = {
        'MusicStatusChange': [{ type: Output },],
        'music': [{ type: Input },],
    };
    return Audiotrackplay;
}());
