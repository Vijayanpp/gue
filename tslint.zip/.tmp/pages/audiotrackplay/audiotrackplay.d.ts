import { EventEmitter } from '@angular/core';
import { Music } from '../../model/musicmodel';
import { WebAudioPlayer } from '../../providers/audio-player-provider';
export declare class Audiotrackplay {
    webAudioPlayer: WebAudioPlayer;
    selectedMusicFile: Music;
    isPlaying: any;
    isPaused: any;
    MusicStatusChange: EventEmitter<any>;
    music: Music;
    constructor(webAudioPlayer: WebAudioPlayer);
    ionViewDidLoad(): void;
    playMusic(src: any): void;
    pauseMusic(): void;
    stopMusic(): void;
    onSelect(music: Music): void;
}
