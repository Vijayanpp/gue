import { Component, ViewChild, Output, EventEmitter } from '@angular/core';
import { Transfer } from 'ionic-native';
import { Platform, NavController } from 'ionic-angular';
import { FetchMusicFiles } from '../../providers/fetch-music-files';
import { WebAudioPlayer } from '../../providers/audio-player-provider';
import { Audiotrackplay } from '../audiotrackplay/audiotrackplay';
import { Audioplayer } from '../audioplayer/audioplayer';
export var Musicfiles = (function () {
    function Musicfiles(navCtrl, fetchMusicFiles, webAudioPlayer, platform) {
        var _this = this;
        this.navCtrl = navCtrl;
        this.fetchMusicFiles = fetchMusicFiles;
        this.webAudioPlayer = webAudioPlayer;
        this.platform = platform;
        this.musicStarted = false;
        this.MusicStatusChanged = new EventEmitter();
        this.platform.registerBackButtonAction(function () {
            _this.stopAllmusic();
        });
    }
    Musicfiles.prototype.ionViewDidLoad = function () {
        this.fetchMusicFileAndShowData();
    };
    Musicfiles.prototype.fetchMusicFileAndShowData = function () {
        var _this = this;
        /*this.musics=MUSIC;*/
        this.fetchMusicFiles.load().subscribe(function (musics) {
            _this.musics = musics;
        });
    };
    Musicfiles.prototype.startNewPlayer = function (src) {
        console.log('igot the message i am going to stop');
        this.webAudioPlayer.stop();
        this.audioplayer.range = 0;
        for (var i = this.musics.length - 1; i >= 0; i--) {
            var tt = this.musics[i];
            this.musics[i].isPlaying = false;
        }
        this.webAudioPlayer.src = src;
        this.webAudioPlayer.createAudio();
        this.webAudioPlayer.play();
    };
    /*downloadMusic(music)
    {
      window.open(music,"_system");
      alert('hi')
    }*/
    Musicfiles.prototype.stopAllmusic = function () {
        this.webAudioPlayer.stop();
        this.navCtrl.pop();
    };
    Musicfiles.prototype.downloadMusic = function (music) {
        var _this = this;
        this.platform.ready().then(function () {
            var fileTransfer = new Transfer();
            var targetPath;
            var options;
            console.log(music + encodeURI(music));
            options = {
                fileKey: 'file',
                fileName: 'ppp.mp3',
                mimeType: "audio/mpeg"
            };
            if (!_this.platform.is('cordova')) {
                return false;
            }
            if (_this.platform.is('ios')) {
                targetPath = cordova.file.documentsDirectory;
            }
            else if (_this.platform.is('android')) {
                targetPath = cordova.file.externalRootDirectory + "/Download/";
            }
            else {
                return false;
            }
            console.log("path:" + targetPath);
            fileTransfer.download(encodeURI("http://www.freedigitalphotos.net/images/img/homepage/87357.jpg"), targetPath + "/87357.jpg", true).then(function (theFile) {
                console.log("download complete: " + theFile.toURI());
                alert("File downloaded to " + targetPath);
            }).catch(function (e) {
            });
        });
    };
    Musicfiles.decorators = [
        { type: Component, args: [{
                    selector: 'page-musicfiles',
                    templateUrl: 'musicfiles.html'
                },] },
    ];
    /** @nocollapse */
    Musicfiles.ctorParameters = [
        { type: NavController, },
        { type: FetchMusicFiles, },
        { type: WebAudioPlayer, },
        { type: Platform, },
    ];
    Musicfiles.propDecorators = {
        'audiotrackplay': [{ type: ViewChild, args: [Audiotrackplay,] },],
        'audioplayer': [{ type: ViewChild, args: [Audioplayer,] },],
        'MusicStatusChanged': [{ type: Output },],
    };
    return Musicfiles;
}());
