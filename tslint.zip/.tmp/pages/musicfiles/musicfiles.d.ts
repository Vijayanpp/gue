import { EventEmitter } from '@angular/core';
import { Platform, NavController } from 'ionic-angular';
import { Music } from '../../model/musicmodel';
import { FetchMusicFiles } from '../../providers/fetch-music-files';
import { WebAudioPlayer } from '../../providers/audio-player-provider';
import { Audiotrackplay } from '../audiotrackplay/audiotrackplay';
import { Audioplayer } from '../audioplayer/audioplayer';
export declare class Musicfiles {
    navCtrl: NavController;
    fetchMusicFiles: FetchMusicFiles;
    webAudioPlayer: WebAudioPlayer;
    platform: Platform;
    audiotrackplay: Audiotrackplay;
    audioplayer: Audioplayer;
    musics: Music[];
    selectedMusicFile: Music;
    musicStarted: boolean;
    MusicStatusChanged: EventEmitter<any>;
    constructor(navCtrl: NavController, fetchMusicFiles: FetchMusicFiles, webAudioPlayer: WebAudioPlayer, platform: Platform);
    ionViewDidLoad(): void;
    fetchMusicFileAndShowData(): void;
    startNewPlayer(src: any): void;
    stopAllmusic(): void;
    downloadMusic(music: any): void;
}
