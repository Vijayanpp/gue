import { Component,ViewChild,Output, EventEmitter } from '@angular/core';
import { Transfer } from 'ionic-native';
import {Platform, NavController, Alert} from 'ionic-angular';
import { Music } from '../../model/musicmodel';
import { FetchMusicFiles } from '../../providers/fetch-music-files';
import { WebAudioPlayer  } from '../../providers/audio-player-provider';
import { Audiotrackplay } from '../audiotrackplay/audiotrackplay';
import { Audioplayer } from '../audioplayer/audioplayer'
declare var cordova:any;

@Component({
  selector: 'page-musicfiles',
  templateUrl: 'musicfiles.html'
})


export class Musicfiles {

 @ViewChild(Audiotrackplay) audiotrackplay:Audiotrackplay;  
 @ViewChild(Audioplayer) audioplayer:Audioplayer;


  public musics:Music[];
  public selectedMusicFile:Music;
  public musicStarted: boolean=false;
   @Output() MusicStatusChanged:EventEmitter<any>= new EventEmitter();


  constructor(public navCtrl: NavController, public fetchMusicFiles:FetchMusicFiles,public webAudioPlayer:WebAudioPlayer,public platform:Platform) {
   this.platform.registerBackButtonAction(()=>
       {
         this.stopAllmusic();
       });
   
  }

  


  ionViewDidLoad() {   
     
     this.fetchMusicFileAndShowData();
  }
  

  fetchMusicFileAndShowData()
  {
    
    /*this.musics=MUSIC;*/
    this.fetchMusicFiles.load().subscribe(musics=>
    {
       this.musics=musics;  
      
    })
  }

  startNewPlayer(src)
  {
    
    console.log('igot the message i am going to stop');
    this.webAudioPlayer.stop();
    this.audioplayer.range=0;
     
    for (var i = this.musics.length - 1; i >= 0; i--) {
      var tt = this.musics[i];
      this.musics[i].isPlaying = false;
    }
  
    this.webAudioPlayer.src=src;   
   
    this.webAudioPlayer.createAudio();
    this.webAudioPlayer.play();
 

  }

 /*downloadMusic(music)
 {
   window.open(music,"_system");
   alert('hi')
 }*/

stopAllmusic()
  {
     this.webAudioPlayer.stop();
     this.navCtrl.pop();
  }



 downloadMusic(music) {
      this.platform.ready().then(() => {
       let fileTransfer =new Transfer();        
        let targetPath;
        let options:any;
console.log(music+encodeURI(music))

options = {
     fileKey: 'file',
     fileName: 'ppp.mp3',
     mimeType: "audio/mpeg"
     
  }
        
   if(!this.platform.is('cordova')) {
          return false;
        }

        if (this.platform.is('ios')) {
          targetPath = cordova.file.documentsDirectory
        }
        else if(this.platform.is('android')) {
            targetPath = cordova.file.externalRootDirectory+"/Download/";     
          
        }
        else {
          return false;
        }
console.log("path:"+targetPath);

			
 fileTransfer.download(encodeURI("http://www.freedigitalphotos.net/images/img/homepage/87357.jpg"),targetPath+"/87357.jpg",true).then((theFile)=>{ console.log("download complete: " + theFile.toURI());
            alert("File downloaded to "+targetPath);}).catch(e => {
    
});
        
      });
    }


  
}


