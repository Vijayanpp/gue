export declare class AudioTimePipe {
    transform(value?: number): string;
}
