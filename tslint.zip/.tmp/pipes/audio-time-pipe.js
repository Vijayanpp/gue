import { Pipe } from '@angular/core';
/*
  Generated class for the AudioTimePipe pipe.

  See https://angular.io/docs/ts/latest/guide/pipes.html for more info on
  Angular 2 Pipes.
*/
export var AudioTimePipe = (function () {
    function AudioTimePipe() {
    }
    AudioTimePipe.prototype.transform = function (value) {
        if (value === undefined || Number.isNaN(value))
            return '';
        var s = Math.trunc(value % 60);
        var m = Math.trunc((value / 60) % 60);
        var h = Math.trunc(((value / 60) / 60) % 60);
        return h > 0 ? (h < 10 ? '0' + h : h) + ":" + (m < 10 ? '0' + m : m) + ":" + (s < 10 ? '0' + s : s) : (m < 10 ? '0' + m : m) + ":" + (s < 10 ? '0' + s : s);
    };
    AudioTimePipe.decorators = [
        { type: Pipe, args: [{
                    name: 'audiotimepipe'
                },] },
    ];
    /** @nocollapse */
    AudioTimePipe.ctorParameters = [];
    return AudioTimePipe;
}());
